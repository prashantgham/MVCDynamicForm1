﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MvcDynamicForms.Fields
{
    public enum Orientation
    {
        Vertical = 0,
        Horizontal = 1
    }
}
